//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by netmeter.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_NETMETTYPE                  129
#define IDB_YELLOW                      133
#define IDB_BLUE                        134
#define IDB_YELL                        135
#define IDB_CAP_WIZ                     175
#define IDD_ADAPTER                     180
#define IDC_ADAPTER                     1000
#define IDC_LIST1                       3109
#define seladapter                      32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
