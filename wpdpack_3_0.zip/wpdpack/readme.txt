* WinPcap Developer's pack    *
* Release 3.0 - August 2002   *


This archive contains all the stuff useful to develop WinPcap-based applications. 
The archive contains the following folders:

- drivers               WinPcap binaries installation. Useful to test the programs.
- lib		        library files that must be linked when using WinPcap.
- include		WinPcap related includes.
- examples              Sample applications showing various uses of of the WinPcap API.
- docs			Complete WinPcap documentation.

see the home page at http://winpcap.polito.it/ for information, details and updates.
